const data = [
    {
        id: 1,
        name: 'triangle',
        image: require('../src/shapes/triangle.png'),
    },
    {
        id: 2,
        name: 'circle',
        image: require('../src/shapes/circle.png'),
    },
    {
        id: 3,
        name: 'waves',
        image: require('../src/shapes/waves.png'),
    },
    {
        id: 4,
        name: 'star',
        image: require('../src/shapes/star.png'),
    },
    {
        id: 5,
        name: 'square',
        image: require('../src/shapes/square.png'),
    },
    {
        id:6,
        name: 'hexagon',
        image: require('../src/shapes/hexagon.png')
    }
];

export default data;
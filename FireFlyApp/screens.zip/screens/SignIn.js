import React, { useState, useEffect} from 'react'
import { StatusBar } from 'expo-status-bar'
import { Button, View, StyleSheet, Text, TextInput, TouchableOpacity } from 'react-native'
import {auth} from '../firebase'

export default function SignIn({navigation}) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')


  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(user => {
      if(user) {
        navigation.navigate("Home")
      }
    })

    return unsubscribe
  }, [])
  
  const handleSignUp = () => {
    auth.createUserWithEmailAndPassword(email, password).then(userCredentials => {
      const user = userCredentials.user;
      console.log(user.email);
    })
    .catch(error => alert(error.message))
  }

  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <TextInput placeholder='Email' style={styles.input} value={email} onChangeText={text => setEmail(text)}/>

        <TextInput placeholder='Password' style={styles.input} value={password} onChangeText={text => setPassword(text)} secureTextEntry/>
      </View>

        <StatusBar style="auto"/>

        <View style={styles.buttonContainer}>
          <TouchableOpacity onPress={handleSignUp} style={styles.button}>
            <Text style={styles.buttonText}>Register</Text>
          </TouchableOpacity>
      
        </View>
        <Text style={{marginTop: 10, fontSize: 14}}>Already have an account? Login <Text onPress={() => {navigation.navigate("SignUp")}} style={{color: '#ef5e5c'}}>here.</Text></Text>
    
    </View>

    
  )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    inputContainer: {
        width: '80%'
    },
    input: {
      borderColor: '#ef5e5c',
      borderBottomWidth: 2,
      borderTopWidth: 0,
      paddingTop: 10,
      marginTop: 20.
      
    },
    buttonText: {
      fontSize: 16,
      color: 'white',

    },
    buttonContainer: {
      width: '60%',
      justifyContent: 'center',
      alignItems: 'center',
      marginTop: 200,
    },
    button: {
      backgroundColor:  '#ef5e5c',
      width: '100%',
      padding: 15,
      borderRadius: 10,
      alignItems: 'center'
    }
});

import React from 'react'
import { Button, View, StyleSheet, Text, TextInput, TouchableOpacity, Image } from 'react-native'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

//import Home from '../screens/Home';
import DetailsScreen from '../screens/DetailsScreen';
import SettingsScreen from '../screens/SettingsScreen';

const Tab = createBottomTabNavigator();

export default function Home() {
   return (
       <Tab.Navigator 
        screenOptions={{
            headerShown: false,
            tabBarShowLabel: false,
            tabBarStyle: {
                position: 'absolute',
                bottom: 25,
                left: 20,
                right: 20,
                elevation: 0,
                backgroundColor: 'white',
                borderRadius: 15,
                height: 90,
            }
        }}
        
       >
            <Tab.Screen name="Home" component={DetailsScreen} options={{
                tabBarIcon: ({focused}) => (
                    <View style={{alignItems: 'center', justifyContent: 'center', top: 10}}>
                        <Image
                            source={require('../assets/home.png')}
                            resizeMode="contain"
                            style={{
                                width: 25,
                                height: 25,
                                tintColor: focused ? '#ef5e5c' : '#748c94',
                            }}
                        />
                        <Text 
                        style={{color: focused ? '#ef5e5c' : '#748c94', fontSize: 12}}
                        >
                            HOME
                        </Text>
                    </View>
                ),
            }} />
            <Tab.Screen name="Settings" component={SettingsScreen} options={{
                tabBarIcon: ({focused}) => (
                    <View style={{alignItems: 'center', justifyContent: 'center', top: 10}}>
                        <Image
                            source={require('../assets/user.png')}
                            resizeMode="contain"
                            style={{
                                width: 25,
                                height: 25,
                                tintColor: focused ? '#ef5e5c' : '#748c94',
                            }}
                        />
                        <Text 
                        style={{color: focused ? '#ef5e5c' : '#748c94', fontSize: 12}}
                        >
                            PROFILE
                        </Text>
                    </View>
                ),
            }}
            
            />
       </Tab.Navigator>
   );
}


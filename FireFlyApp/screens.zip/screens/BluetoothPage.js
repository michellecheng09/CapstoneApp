import NetInfo from '@react-native-community/netinfo';
import AnimatedLottieView from 'lottie-react-native';
import { Button, View, StyleSheet, Text, TextInput, TouchableOpacity, Image } from 'react-native';

import { SafeAreaView } from 'react-native-safe-area-context';

export default function BluetoothPage() {
    const handleGetNetInfo = () => {
        NetInfo.fetch().then(state => {
        console.log('Connection type', state.type);
        console.log('Is connected?', state.isConnected);
        console.log('SSID', state.details?.ssid); // Logs the network name (SSID)
        if (state.isConnected && state.details?.ssid === 'FireFly') {
            console.log('Connected to FireFly network!');
            // Do something else
            fetch('http://192.168.0.1/api/getStatus')
            .then(response => response.json())
            .then(data => {
              console.log('Drone status:', data);
            })
            .catch(error => {
              console.error('Error communicating with drone:', error);
            });
          
        }
        });
    }
    
    

      return (
        <SafeAreaView>
            <View>
                <TouchableOpacity style={{marginTop: 100, marginLeft: 100, backgroundColor: 'grey', width: 100,}} onPress={handleGetNetInfo}>
                    <Text>Connect</Text>
                </TouchableOpacity>
            </View>
            <View>
                
                <AnimatedLottieView source={require('../assets/images/loading.json')} autoPlay loop></AnimatedLottieView>
            
            </View>
        </SafeAreaView>

      );



};


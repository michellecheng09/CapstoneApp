import * as React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {auth} from '../firebase'

export default function SettingsScreen({ navigation }) {
    const handleSignOut = () => {
        auth.signOut().then(() => navigation.navigate("SignIn"));
    }


    return (
        <SafeAreaView>
            <View style={{height: 150, backgroundColor: '#ef5e5c' }}>
                <Image style={{width:160, height: 160, tintColor: '#f2f2f2', marginTop: 20, marginLeft: 15}} source={require("../assets/account.png")}/>
            </View>
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
                <Text
                    onPress={() => navigation.navigate('Home')}
                    style={{ fontSize: 26, fontWeight: 'bold' }}>Settings Screen</Text>
            </View>
            <View style={{width: '30%', justifyContent: 'center', alignItems:'center', marginTop: '50%', marginLeft: '35%'}}>
                <TouchableOpacity style={{backgroundColor: '#ef5e5c', width: '100%', padding: 15, borderRadius: 10}} onPress={handleSignOut}>
                    <Text style={{color: 'white', fontWeight: '700', marginLeft:15}}>
                        Logout
                    </Text>
                </TouchableOpacity>
            </View>
        </SafeAreaView>
   );
}




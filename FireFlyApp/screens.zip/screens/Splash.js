import React from 'react'
import { StatusBar } from 'expo-status-bar'
import {Image, Text, Button, View, StyleSheet, TouchableOpacity } from 'react-native'

export default function Splash({navigation}) {
  return (
    <View style={styles.container}>
        <Image source={require('../assets/logo.png')} style={{width:300, height: 300, marginLeft: 20}}/>

        <View style={styles.buttonContainer}>
            <TouchableOpacity
                style={styles.button}
                onPress={() => navigation.navigate("SignIn")}
            >
                <Text style ={styles.buttonText}>Get Started!</Text>
            </TouchableOpacity>
        </View>
    
        <StatusBar style="auto"/>
    </View>

   
  )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    buttonContainer:{
        width: '30%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        color: 'white',
        fontWeight: '700',
        
    },
    button: {
        backgroundColor: '#ef5e5c',
        width:'100%',
        padding: 15,
        borderRadius: 10,
    }
});

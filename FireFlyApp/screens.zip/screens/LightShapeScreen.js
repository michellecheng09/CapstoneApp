import { View, Text, SafeAreaView, StyleSheet, FlatList, Image, TouchableHighlight, TouchableOpacity, Alert} from 'react-native'
import React, { useState } from 'react'
import data from '../src/data'

export default function LightShapeScreen() {
const [clickedId, setClickedId] = useState(0)

  const renderItem = ({item, index}) => {
    return (
        <View style={styles.listContainer}>
          <TouchableOpacity onPress={(item) => handleShapeSelect(item, index)} >
            <View style={styles.imageContainer}>
                <Image source={item.image} style={styles.image}/>
            </View>
          </TouchableOpacity>
        </View>
    )
  }

  const selectShape = () => {

  }

  const handleShapeSelect = (item, id) => {
    if(id > 2){
      alert('This shape sequence requires more than 3 drones')
    }
    
  }



  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={data}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        numColumns={2}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}




const styles = StyleSheet.create({
  container: {
      flex: 1,
      marginTop: 140,


  },
  listContainer: {
    flex: 1,
    backgroundColor: '#ef5e5c',
    margin: 10,
    borderRadius: 20,
    shadowColor: 'black',
    elevation: 6,
    shadowOffset: {height: 1, width: 1},


  },
  imageContainer: {
    margin: 15,
    borderRadius: 10,
    overflow: 'hidden'

  },
  image: {
      width: 90,
      height: 90,
      aspectRatio: 1,
      margin:10,
      marginLeft: 20,
      tintColor: 'white'
  }
});



import * as React from 'react';
import { View, Text, Image, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const DATA = [
    {
        name: 'Connect Drones',
        img: require("../assets/link.png")
    },
    {
        name: 'Make Lights Sequence',
        img: require("../assets/drone.png")
    },
]

export default function DetailsScreen({ navigation }) {
   return (
    <SafeAreaView>
        <View style={styles.container}>
            <Image
            source={require('../assets/logo.png')}
            style={{
                width: 200,
                height: 200,
            }}
            />
        </View>
        <FlatList
            contentContainerStyle={{ marginTop: 0, paddingTop: 0}}
            horizontal
            showsVerticalScrollIndicator={false}
        />
        <TouchableOpacity
        style={{
            width: 320,
            marginLeft: 20,
            borderRadius: 10,
            backgroundColor: 'white',
            paddingVertical: 24 ,
            paddingHorizontal: 24 ,
            marginRight: 24 ,
            marginTop: 0,
            shadowColor: 'black',
            shadowOffset: {height: 1, width: 1},
            elevation: 5,
        }}

        >
            <View style={{flexDirection: "row"}}>
                <View>
                    <Image
                        source={require("../assets/connect.png")}
                        resizeMode="cover"
                        style={{
                            marginTop: 5,
                            width: 40,
                            height: 40,
                            marginRight: 25,
                        }}
                    />
                </View>
                <View>
                    <Text style={{fontSize: 20, paddingTop: 10}}>Connect Your Drones</Text>
                </View>
            </View>
        </TouchableOpacity>
        <TouchableOpacity
        style={{
            width: 320,
            marginLeft: 20,
            borderRadius: 10,
            backgroundColor: 'white',
            paddingVertical: 24 ,
            paddingHorizontal: 24 ,
            marginRight: 24 ,
            marginTop: 25,
            shadowColor: 'black',
            shadowOffset: {height: 1, width: 1},
            elevation: 5,
        }}
        onPress={() => navigation.navigate("LightShape")}
        >
            <View style={{flexDirection: "row"}}>
                <View>
                    <Image
                        source={require("../assets/drone.png")}
                        resizeMode="cover"
                        style={{
                            marginTop: 5,
                            width: 40,
                            height: 40,
                            marginRight: 25,
                        }}
                    />
                </View>
                <View>
                    <Text style={{fontSize: 20, paddingTop: 10}}>Make Light Sequence</Text>
                </View>
            </View>
        </TouchableOpacity>
    </SafeAreaView>
   );
}

const styles = StyleSheet.create({
    container: {
        height: 300,
        alignItems: 'center',
        justifyContent: 'center',
    }

});




import React from 'react'
import { Button, View, StyleSheet, Text, TextInput, TouchableOpacity } from 'react-native'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import Home from '../screens/Home';
import DetailsScreen from '../screens/DetailsScreen';
import SettingsScreen from '../screens/SettingsScreen';

const Tab = createBottomTabNavigator();

export default function Tabs() {
   return (
       <Tab.Navigator>
            <Tab.Screen name="Home" component={Home} />
            <Tab.Screen name="Details" component={DetailsScreen} />
            <Tab.Screen name="Settings" component={SettingsScreen} />
       </Tab.Navigator>
   );
}

